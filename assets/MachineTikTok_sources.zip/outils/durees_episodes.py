import json,glob,sys
for p in sorted(glob.glob('mcp-SUNO-audio-lyrics-alignment-*.txt')):
    try: t=json.loads(open(p).read())
    except Exception as e: print(p,'ERR',e); continue
    w=t['words'];
    if not w: continue
    st=[x['start_s'] for x in w if '[Shout]' in x['word']]
    end=w[-1]['end_s']; b=st+[end+0.8]
    print(t['audio_id'][:8],[round(b[i+1]-b[i],1) for i in range(len(st))],'starts',[round(s,1) for s in st])
