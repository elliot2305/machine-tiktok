const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch({args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
const p=await b.newPage({viewport:{width:1080,height:1920}});p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('http://127.0.0.1:8792/'+process.env.PAGE);await p.waitForFunction('window.READY',null,{timeout:60000});
const out=process.env.OUT;fs.mkdirSync(out,{recursive:true});const a=+process.env.A,z=+process.env.Z;
for(let k=a;k<z;k++){await p.evaluate(t=>render(t),k/30);await p.screenshot({path:`${out}/${String(k).padStart(5,'0')}.jpg`,type:'jpeg',quality:90})}
console.log('ok',a,z);await b.close()})();
